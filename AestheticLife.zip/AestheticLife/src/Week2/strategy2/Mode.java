package Week2.strategy2;

public interface Mode {
    public void timeTo();
}
