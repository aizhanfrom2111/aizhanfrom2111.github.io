package Week2.strategy2;

public class Cutting implements Mode{
    @Override
    public void timeTo() {
        System.out.println("Eat Less, than you train");
    }
}
