package Week2.strategy1;

public class Friday implements WeGoJim {
    @Override
    public void toTrainWhat() {
        System.out.println("Back and Chest");
    }
}
