package Week2.strategy1;

public class Sunday implements WeGoJim {
    @Override
    public void toTrainWhat() {
        System.out.println("Legs, Hamstring focused");
    }
}
