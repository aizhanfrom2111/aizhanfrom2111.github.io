package Week2.strategy1;

public class Tuesday implements WeGoJim {
    @Override
    public void toTrainWhat() {
        System.out.println("Back and Biceps");
    }
}
