package Week2.strategy1;

public class Monday implements WeGoJim {
    @Override
    public void toTrainWhat() {
    System.out.println("Chest, Triceps and Shoulders");
    }
}
