package Week2.strategy1;

public class Thursday implements WeGoJim {
    @Override
    public void toTrainWhat() {
        System.out.println("Rest");
    }
}
