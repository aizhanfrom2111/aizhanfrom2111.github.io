package Week2.strategy1;

public class Saturday implements WeGoJim {
    @Override
    public void toTrainWhat() {
        System.out.println("Arms and Shoulders");
    }
}
