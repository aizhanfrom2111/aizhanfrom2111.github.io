package Week2.strategy1;

public interface WeGoJim {
    public void toTrainWhat();
}
